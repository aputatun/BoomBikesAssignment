SET ECHO ON;
/*************************************************************************
Name	: Expat Housing Sequence Creation Script
Author	: Perwez Rizwi
Date	: 2-Aug-2024	
*************************************************************************/

/*************************************************************************
Creating sequence for storing contract beneficiary details
XXADG_EXPAT_HOUSING_BENEFICIARY_DETS_STG_S

*************************************************************************/
CREATE SEQUENCE  "XXADG_EXPAT_HOUSING_BENEFICIARY_DETS_STG_S"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 6 NOCACHE  NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;


/*************************************************************************
Creating sequence for generating contract number
XXADG_EXPAT_HOUSING_CONTRACT_NUMBER_SEQ

*************************************************************************/

CREATE SEQUENCE  "XXADG_EXPAT_HOUSING_CONTRACT_NUMBER_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1122 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;

/*************************************************************************
Creating sequence for generating reference number
XXADG_EXPAT_HOUSING_REF_NUMBER_SEQ

*************************************************************************/

CREATE SEQUENCE  "XXADG_EXPAT_HOUSING_REF_NUMBER_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1281 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;