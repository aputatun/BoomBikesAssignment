SET ECHO ON;
/*************************************************************************
Name	: Expat Housing Table Creation Script
Author	: Perwez Rizwi
Date	: 2-Aug-2024	
*************************************************************************/

/*************************************************************************
Creating table for storing contract details for both new and renewal requests
XXADG_EXPAT_HOUSING_CONTRACT_DETS_STG

contract_status:
Awaiting Approval (status_reason: not applicable)
Approved (status_reason: not applicable)
Rejected (status_reason: not applicable)
Error  (status_reason: <error details>)
*************************************************************************/
 CREATE TABLE "XXADG_EXPAT_HOUSING_CONTRACT_DETS_STG" 
   (	"CONTRACT_NUMBER" VARCHAR2(100), 
	"REFERENCE_NUMBER" VARCHAR2(100), 
	"REQUEST_TYPE" VARCHAR2(30), 
	"PERSON_EMAIL" VARCHAR2(100), 
	"HIRE_DATE" DATE, 
	"LANDLORD_NAME" VARCHAR2(100), 
	"LANDLORD_TELEPHONE" VARCHAR2(20), 
	"AGENT_NAME" VARCHAR2(100), 
	"AGENT_TELEPHONE" VARCHAR2(20), 
	"BENEFICIARY_NAME" VARCHAR2(100), 
	"BENEFICIARY_BANK" VARCHAR2(100), 
	"BENEFICIARY_IBAN" VARCHAR2(100), 
	"BUILDING_NAME" VARCHAR2(100), 
	"BUILDING_ADDRESS_1" VARCHAR2(100), 
	"BUILDING_ADDRESS_2" VARCHAR2(100), 
	"CITY" VARCHAR2(30), 
	"UNIT_TYPE" VARCHAR2(30), 
	"FLOOR_NUM" VARCHAR2(20), 
	"FLAT_VILLA_NUM" VARCHAR2(20), 
	"CONTRACT_START_DATE" DATE, 
	"CONTRACT_END_DATE" DATE, 
	"RENT_AMOUNT" NUMBER, 
	"GRADE_ENTITLEMENT" VARCHAR2(30), 
	"RENEWAL_ITERATION" NUMBER, 
	"LAST_UPDATED_BY" VARCHAR2(100), 
	"LAST_UPDATED_ON" TIMESTAMP (6), 
	"CONTRACT_STATUS" VARCHAR2(30), 
	"STATUS_REASON" VARCHAR2(100), 
	"DOCUMENT_OF_RECORD_ID" VARCHAR2(50), 
	 PRIMARY KEY ("REFERENCE_NUMBER")
  USING INDEX  ENABLE
   ) ;
/************************************************************************/


/*************************************************************************
Creating table for storing proof details for both new and renewal requests
XXADG_EXPAT_HOUSING_PROOF_DETS_STG

contract_status:
Awaiting Approval (status_reason: not applicable)
Approved (status_reason: not applicable)
Rejected (status_reason: not applicable)
Error  (status_reason: <error details>)
*************************************************************************/
CREATE TABLE "XXADG_EXPAT_HOUSING_PROOF_DETS_STG" 
(	"CONTRACT_NUMBER" VARCHAR2(100), 
"REFERENCE_NUMBER" VARCHAR2(100), 
"PROOF_STATUS" VARCHAR2(30), 
"STATUS_REASON" VARCHAR2(100), 
"PROOF_ATTACHMENT" CLOB, 
"LAST_UPDATED_BY" VARCHAR2(100), 
"LAST_UPDATED_ON" TIMESTAMP (6), 
 PRIMARY KEY ("REFERENCE_NUMBER")
USING INDEX  ENABLE
) ;
/************************************************************************/


/*************************************************************************
Creating table for storing person details
XXADG_EXPAT_HOUSING_PERSON_DETS_STG
*************************************************************************/
  CREATE TABLE "XXADG_EXPAT_HOUSING_PERSON_DETS_STG" 
   (	"PERSON_NUMBER" VARCHAR2(10), 
	"PERSON_EMAIL" VARCHAR2(100), 
	"PERSON_NAME" VARCHAR2(100), 
	"PERSON_GRADE" VARCHAR2(30), 
	"HIRE_DATE" DATE, 
	"PROBATION_START_DATE" DATE, 
	"PROBATION_END_DATE" DATE, 
	"PROBATION_STATUS" VARCHAR2(30), 
	"NATIONALITY_TYPE" VARCHAR2(30), 
	"LEGAL_ENTITY_CODE" VARCHAR2(30), 
	"LEGAL_ENTITY_NAME" VARCHAR2(100), 
	"CURRENT_GRADE_ENTITLEMENT" VARCHAR2(30), 
	 PRIMARY KEY ("PERSON_NUMBER")
  USING INDEX  ENABLE
   ) ;


/*************************************************************************
Creating table for storing invoice details
XXADG_EXPAT_HOUSING_INVOICE_DETS_STG
*************************************************************************/
CREATE TABLE "XXADG_EXPAT_HOUSING_INVOICE_DETS_STG" 
   (	"INVOICE_NUMBER" VARCHAR2(20), 
	"PERSON_NUMBER" VARCHAR2(10), 
	"PERSON_EMAIL" VARCHAR2(100), 
	"CONTRACT_NUMBER" VARCHAR2(20), 
	"REFERENCE_NUMBER" VARCHAR2(20), 
	"GROUP_ID" VARCHAR2(20), 
	"CONTRACT_STATUS" VARCHAR2(30), 
	"STATUS_REASON" VARCHAR2(100), 
	 PRIMARY KEY ("INVOICE_NUMBER")
  USING INDEX  ENABLE
   ) ;

/*************************************************************************
Creating table for storing beneficiary details
XXADG_EXPAT_HOUSING_BENEFICIARY_DETS_STG
*************************************************************************/
CREATE TABLE "XXADG_EXPAT_HOUSING_BENEFICIARY_DETS_STG" 
   (	"ID" NUMBER DEFAULT "DGE_HCM_INT"."XXADG_EXPAT_HOUSING_BENEFICIARY_DETS_STG_S"."NEXTVAL", 
	"BENEFICIARY_NATIONAL_ID" VARCHAR2(20), 
	"BENEFICIARY_NAME" VARCHAR2(100), 
	"BENEFICIARY_BANK" VARCHAR2(100), 
	"BANK_BRANCH_NAME" VARCHAR2(100), 
	"BENEFICIARY_IBAN" VARCHAR2(100), 
	"BENEFICIARY_EMAIL_ADDRESS" VARCHAR2(200), 
	"BENEFICIARY_TAX_REG_NUMBER" VARCHAR2(200), 
	"ADDRESS_LINE_1" VARCHAR2(100), 
	"ADDRESS_LINE_2" VARCHAR2(100), 
	"CITY" VARCHAR2(30), 
	"STATE" VARCHAR2(240), 
	"POSTAL_CODE" VARCHAR2(200), 
	"COUNTRY" VARCHAR2(80), 
	"ACCOUNT_COUNTRY_CODE" VARCHAR2(200), 
	"ACCOUNT_CURRENCY_CODE" VARCHAR2(40), 
	"ACCOUNT_TYPE_CODE" VARCHAR2(40), 
	"BUSINESS_UNIT" VARCHAR2(240), 
	"CURRENCY" VARCHAR2(80), 
	"PAYMENT_METHOD" VARCHAR2(100), 
	"DISTRIBUTION_COMBINATION" VARCHAR2(400), 
	"DISTRIBUTION_SET" VARCHAR2(200), 
	"LAST_UPDATED_BY" VARCHAR2(100), 
	"LAST_UPDATED_ON" TIMESTAMP (6)
   ) ;