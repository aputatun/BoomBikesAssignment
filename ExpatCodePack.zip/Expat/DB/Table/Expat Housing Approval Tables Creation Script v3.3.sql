SET ECHO ON;
/*************************************************************************
Name	: Expat Housing Approval Tables Creation Script
Author	: Perwez Rizwi/Ankan Putatunda
Date	: 13-Aug-2024	
*************************************************************************/

/*************************************************************************
Table to store applications
XXADG_HCM_OPA_APPLICATIONS_TBL
*************************************************************************/
CREATE TABLE "XXADG_HCM_OPA_APPLICATIONS_TBL" 
(	"APPLICATION_ID" VARCHAR2(30), 
"APPLICATION_NAME" VARCHAR2(100), 
"APPLICATION_CODE" VARCHAR2(100), 
"EMBEDDED_APP_URL" VARCHAR2(1500), 
"ATTRIBUTE_1" VARCHAR2(30), 
"ATTRIBUTE_2" VARCHAR2(30), 
"ATTRIBUTE_3" VARCHAR2(100), 
"ATTRIBUTE_4" VARCHAR2(100), 
"CREATED_BY" VARCHAR2(100), 
"CREATION_DATE" TIMESTAMP (6), 
"LAST_UPDATED_BY" VARCHAR2(100), 
"LAST_UPDATED_ON" TIMESTAMP (6), 
 PRIMARY KEY ("APPLICATION_ID")
USING INDEX  ENABLE
);
/************************************************************************/


/*************************************************************************
Table to store entity header names
XXADG_HCM_OPA_HEADERS_TBL
*************************************************************************/
CREATE TABLE "XXADG_HCM_OPA_HEADERS_TBL" 
(	"ENTITY_HEADER_ID" VARCHAR2(30), 
"ENTITY_HEADER_NAME" VARCHAR2(240), 
"APPLICATION_ID" VARCHAR2(30), 
"ENABLED_FLAG" VARCHAR2(1), 
"START_DATE" TIMESTAMP (6), 
"END_DATE" TIMESTAMP (6), 
"ATTRIBUTE_1" VARCHAR2(30), 
"ATTRIBUTE_2" VARCHAR2(30), 
"ATTRIBUTE_3" VARCHAR2(100), 
"ATTRIBUTE_4" VARCHAR2(100), 
"CREATED_BY" VARCHAR2(100), 
"CREATION_DATE" TIMESTAMP (6), 
"LAST_UPDATED_BY" VARCHAR2(100), 
"LAST_UPDATED_ON" TIMESTAMP (6), 
 PRIMARY KEY ("ENTITY_HEADER_ID")
USING INDEX  ENABLE
) ;
/************************************************************************/


/*************************************************************************
Table to store entity detail values
XXADG_HCM_OPA_DETAILS_TBL
*************************************************************************/
CREATE TABLE "XXADG_HCM_OPA_DETAILS_TBL" 
   (	"ENTITY_DETAIL_ID" VARCHAR2(30), 
	"ENTITY_VALUE" VARCHAR2(100), 
	"ENTITY_HEADER_ID" VARCHAR2(30), 
	"APPLICATION_ID" VARCHAR2(30), 
	"ENABLED_FLAG" VARCHAR2(1), 
	"START_DATE" TIMESTAMP (6), 
	"END_DATE" TIMESTAMP (6), 
	"ATTRIBUTE_1" VARCHAR2(30), 
	"ATTRIBUTE_2" VARCHAR2(30), 
	"ATTRIBUTE_3" VARCHAR2(100), 
	"ATTRIBUTE_4" VARCHAR2(100), 
	"CREATED_BY" VARCHAR2(100), 
	"CREATION_DATE" TIMESTAMP (6), 
	"LAST_UPDATED_BY" VARCHAR2(100), 
	"LAST_UPDATED_ON" TIMESTAMP (6), 
	 PRIMARY KEY ("ENTITY_DETAIL_ID")
  USING INDEX  ENABLE
   ) ;
/************************************************************************/


/*************************************************************************
Table to store approval groups
XXADG_HCM_OPA_APPROVAL_GROUPS_TBL
*************************************************************************/
CREATE TABLE "XXADG_HCM_OPA_APPROVAL_GROUPS_TBL" 
	(	"APPROVAL_GROUP_ID" VARCHAR2(30), 
	"APPROVAL_GROUP_NAME" VARCHAR2(100), 
	"ENTITY_DETAIL_ID" VARCHAR2(30), 
	"ENABLED_FLAG" VARCHAR2(1), 
	"START_DATE" TIMESTAMP (6), 
	"END_DATE" TIMESTAMP (6), 
	"ATTRIBUTE_1" VARCHAR2(30), 
	"ATTRIBUTE_2" VARCHAR2(30), 
	"ATTRIBUTE_3" VARCHAR2(100), 
	"ATTRIBUTE_4" VARCHAR2(100), 
	"CREATED_BY" VARCHAR2(100), 
	"CREATION_DATE" TIMESTAMP (6), 
	"LAST_UPDATED_BY" VARCHAR2(100), 
	"LAST_UPDATED_ON" TIMESTAMP (6), 
	 PRIMARY KEY ("APPROVAL_GROUP_ID")
	USING INDEX  ENABLE
	) ;
/************************************************************************/


/*************************************************************************
Table to store approvers
XXADG_HCM_OPA_APPROVERS_TBL
*************************************************************************/
CREATE TABLE "XXADG_HCM_OPA_APPROVERS_TBL" 
   (	"APPROVERS_ID" VARCHAR2(30), 
	"APPROVAL_GROUP_ID" VARCHAR2(30), 
	"APPROVER_PERSON_NAME" VARCHAR2(100), 
	"APPROVER_EMAIL" VARCHAR2(100), 
	"PERSON_NUMBER" VARCHAR2(10), 
	"ENTITY_DETAIL_ID" VARCHAR2(30), 
	"APPROVAL_SEQUENCE" NUMBER, 
	"MANDATORY_FLAG" VARCHAR2(1), 
	"ENABLED_FLAG" VARCHAR2(1), 
	"START_DATE" TIMESTAMP (6), 
	"END_DATE" TIMESTAMP (6), 
	"ATTRIBUTE_1" VARCHAR2(30), 
	"ATTRIBUTE_2" VARCHAR2(30), 
	"ATTRIBUTE_3" VARCHAR2(100), 
	"ATTRIBUTE_4" VARCHAR2(100), 
	"CREATED_BY" VARCHAR2(100), 
	"CREATION_DATE" TIMESTAMP (6), 
	"LAST_UPDATED_BY" VARCHAR2(100), 
	"LAST_UPDATED_ON" TIMESTAMP (6), 
	 PRIMARY KEY ("APPROVERS_ID")
  USING INDEX  ENABLE
   ) ;
/************************************************************************/


/*************************************************************************
Table to store approval rules
XXADG_HCM_OPA_RULES_TBL
*************************************************************************/
CREATE TABLE "XXADG_HCM_OPA_RULES_TBL" 
   (	"APPROVAL_RULE_ID" VARCHAR2(30), 
	"RULE_NAME" VARCHAR2(100), 
	"RULE_QUERY" CLOB, 
	"RULE_SEQUENCE" NUMBER, 
	"PROCESS_MODE" VARCHAR2(30), 
	"APPLICATION_ID" VARCHAR2(30), 
	"ENABLED_FLAG" VARCHAR2(1), 
	"START_DATE" TIMESTAMP (6), 
	"END_DATE" TIMESTAMP (6), 
	"ATTRIBUTE_1" VARCHAR2(30), 
	"ATTRIBUTE_2" VARCHAR2(30), 
	"ATTRIBUTE_3" VARCHAR2(100), 
	"ATTRIBUTE_4" VARCHAR2(100), 
	"CREATED_BY" VARCHAR2(100), 
	"CREATION_DATE" TIMESTAMP (6), 
	"LAST_UPDATED_BY" VARCHAR2(100), 
	"LAST_UPDATED_ON" TIMESTAMP (6), 
	"APPROVAL_GROUP_ID" NUMBER, 
	 PRIMARY KEY ("APPROVAL_RULE_ID")
  USING INDEX  ENABLE
   ) ;
/************************************************************************/


/*************************************************************************
Table to store approval history
XXADG_HCM_OPA_RULES_TBL
*************************************************************************/
 CREATE TABLE "XXADG_OPA_APPROVAL_TRANSACTION_TBL" 
   (	"APPROVAL_HIST_ID" NUMBER GENERATED ALWAYS AS IDENTITY MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  NOT NULL ENABLE, 
	"TRANSACTION_ID" VARCHAR2(30), 
	"APPLICATION_ID" VARCHAR2(30), 
	"VERSION_NUM" NUMBER, 
	"APPROVER_EMAIL" VARCHAR2(100), 
	"WORKFLOW_INSTANCE_ID" VARCHAR2(100), 
	"APPROVER_LEVEL" NUMBER, 
	"APPROVAL_STATUS" VARCHAR2(30), 
	"APPROVAL_SUBMISSION_DATE" TIMESTAMP (6), 
	"ACTION_TAKEN_DATE" TIMESTAMP (6), 
	"APPROVAL_SUBMITTED_BY" VARCHAR2(100), 
	"APPROVED_DATE" TIMESTAMP (6), 
	"FINAL_APPROVAL_ACTION" VARCHAR2(30), 
	"ATTRIBUTE_1" VARCHAR2(30), 
	"ATTRIBUTE_2" VARCHAR2(30), 
	"ATTRIBUTE_3" VARCHAR2(100), 
	"ATTRIBUTE_4" VARCHAR2(100), 
	"CREATED_BY" VARCHAR2(100), 
	"CREATION_DATE" TIMESTAMP (6), 
	"LAST_UPDATED_BY" VARCHAR2(100), 
	"LAST_UPDATED_ON" TIMESTAMP (6), 
	"TRANSACTION_TYPE" VARCHAR2(20), 
	 PRIMARY KEY ("APPROVAL_HIST_ID")
  USING INDEX  ENABLE
   ) ;
/************************************************************************/


/*************************************************************************
Commit changes
*************************************************************************/
commit;